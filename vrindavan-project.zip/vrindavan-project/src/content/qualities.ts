export type Quality = {
  title: string;
  description: string;
};

export const qualities: Quality[] = [
  {
    title: "An Evolving Practice, Not a Formula",
    description:
      "We deliberately avoid a signature style. Each project is a fresh response to its brief, its site, and its client — which is why our portfolio spans heritage homes, farmhouses, cafés, and studio apartments with no two looking alike.",
  },
  {
    title: "Ecological Conviction",
    description:
      "Sustainable design is not an add-on for us. It has been central to our practice since our years in Auroville. We bring material knowledge, passive design strategies, and ecological sensitivity to every commission.",
  },
  {
    title: "Published, Peer-Recognised Work",
    description:
      "Our projects have been featured in Architectural Digest, Elle Decor, and ArchDaily — not through self-promotion, but because the work stands up to editorial scrutiny.",
  },
  {
    title: "Two Disciplines, One Vision",
    description:
      "With Ranjeet's architectural training and Shreenu's interior design expertise working in tandem from the outset, architecture and interiors are conceived as a single integrated experience rather than handed off between separate teams.",
  },
  {
    title: "Honest, Direct Engagement",
    description:
      "We take on a limited number of projects at a time to ensure that every client receives the founders' personal attention from brief to handover.",
  },
];
