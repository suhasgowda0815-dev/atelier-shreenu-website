export const site = {
  name: "The Vrindavan Project",
  tagline: "Architecture and Interior Design",
  founded: 2012,
  description:
    "Contextual, conscious and soulful design. Architecture and interiors rooted in place.",
  founders: "Ranjeet & Shreenu Mukherjee",

  contact: {
    email: "thevrindavanproject@gmail.com",
    phone: "+91 95601 07193",
    phoneIntl: "919560107193",
    whatsapp: "919560107193",
    address: {
      line1: "Celebrity Homes",
      line2: "Palam Vihar",
      city: "Gurugram",
      state: "Haryana",
      postal: "122017",
      country: "India",
    },
    mapsUrl: "https://g.page/The-Vrindavan-Project?share",
  },

  social: {
    instagram: "https://www.instagram.com/thevrindavanproject/",
    facebook: "https://www.facebook.com/The.Vrindavan.Project",
    linkedin: "https://www.linkedin.com/company/the-vrindavan-project/",
    youtube: "https://www.youtube.com/@RanjeetMukherjeeArchitect",
  },

  nav: [
    { label: "Work", href: "#work" },
    { label: "Approach", href: "#approach" },
    { label: "Studio", href: "#studio" },
    { label: "Press", href: "#press" },
    { label: "Contact", href: "#contact" },
  ],

  // First video from the PDF brief, used in the Film section
  filmVideoId: "Sb0wXYPINFY",
};
