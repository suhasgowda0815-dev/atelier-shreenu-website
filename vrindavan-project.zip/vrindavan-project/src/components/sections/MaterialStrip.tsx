import Image from "next/image";
import { Container } from "@/components/ui/Container";
import { FadeIn } from "@/components/ui/FadeIn";

const textures = [
  { src: "/images/texture/01.jpg", alt: "Weathered wood grain" },
  { src: "/images/texture/02.jpg", alt: "Hand-fired brick detail" },
  { src: "/images/texture/03.jpg", alt: "Artisanal ceramic" },
  { src: "/images/texture/04.jpg", alt: "Handwoven linen" },
  { src: "/images/texture/05.jpg", alt: "Concrete and stone" },
];

export function MaterialStrip() {
  return (
    <section className="bg-ink py-20 text-bone md:py-28">
      <Container>
        <FadeIn>
          <div className="mb-12 flex items-center gap-4">
            <div className="h-px w-12 bg-bone/40" />
            <span className="text-micro text-bone/70">Material & Detail</span>
          </div>
        </FadeIn>
      </Container>

      <div className="flex gap-3 overflow-x-auto px-6 pb-4 md:gap-4 md:px-12 lg:px-20">
        {textures.map((t, i) => (
          <FadeIn
            key={i}
            delay={i * 0.08}
            className="relative aspect-[3/4] w-[65vw] shrink-0 overflow-hidden md:w-[28vw] lg:w-[22vw]"
          >
            <Image
              src={t.src}
              alt={t.alt}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 65vw, 28vw"
            />
          </FadeIn>
        ))}
      </div>
    </section>
  );
}
