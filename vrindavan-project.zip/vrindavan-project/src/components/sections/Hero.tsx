import Image from "next/image";
import { FadeIn } from "@/components/ui/FadeIn";

export function Hero() {
  return (
    <section className="relative min-h-screen w-full overflow-hidden">
      {/* Background image (right half on desktop, full on mobile) */}
      <div className="absolute inset-y-0 right-0 w-full md:w-1/2">
        <Image
          src="/images/hero/hero-main.jpg"
          alt="Interior — The Vrindavan Project"
          fill
          priority
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 50vw"
        />
        <div className="absolute inset-0 bg-bone/30 md:hidden" />
      </div>

      {/* Left content panel */}
      <div className="relative z-10 grid min-h-screen md:grid-cols-2">
        <div className="flex flex-col justify-end bg-bone/95 px-6 pb-20 pt-32 backdrop-blur-sm md:bg-bone md:px-20 md:pb-24 md:pt-40 md:backdrop-blur-none">
          {/* Devanagari texture behind the headline */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute left-0 top-1/3 -z-0 select-none font-serif text-[180px] leading-none text-ink/[0.06] md:text-[280px]"
          >
            वृन्दावन
          </div>

          <FadeIn className="relative">
            <div className="mb-6 flex items-center gap-3 text-micro text-terracotta">
              <span>वृन्दावन</span>
              <span>—</span>
              <span>Est. 2012</span>
            </div>

            <h1 className="font-serif text-[56px] leading-[1.04] tracking-tight md:text-[96px]">
              Contextual,
              <br />
              <span className="italic">conscious</span> &<br />
              soulful design.
            </h1>

            <p className="mt-8 max-w-md text-base leading-relaxed text-ink/75 md:text-lg">
              Architecture and interiors rooted in place — by Ranjeet & Shreenu Mukherjee,
              practising across India since 2012.
            </p>
          </FadeIn>

          <FadeIn delay={0.3} className="mt-12 flex items-center gap-8 md:mt-16">
            <a
              href="#work"
              className="text-micro border border-ink/60 px-7 py-3.5 transition-all duration-500 hover:bg-ink hover:text-bone"
            >
              See the work
            </a>
            <a
              href="#approach"
              className="text-micro border-b border-ink/40 pb-1 transition-all hover:border-ink"
            >
              Our approach
            </a>
          </FadeIn>
        </div>

        {/* Right half is the image */}
        <div className="hidden md:block" />
      </div>
    </section>
  );
}
