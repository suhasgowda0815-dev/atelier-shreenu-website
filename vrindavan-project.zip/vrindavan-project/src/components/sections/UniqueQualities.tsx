import { Container } from "@/components/ui/Container";
import { FadeIn } from "@/components/ui/FadeIn";
import { SectionLabel, SectionHeading } from "@/components/ui/SectionHeading";
import { qualities } from "@/content/qualities";

export function UniqueQualities() {
  return (
    <section className="border-t border-ink/10 py-24 md:py-36">
      <Container>
        <FadeIn className="mb-16 md:mb-24 md:max-w-4xl">
          <SectionLabel className="mb-6 block">Why this practice</SectionLabel>
          <SectionHeading>
            Built on five
            <br />
            <span className="italic">uncompromising beliefs.</span>
          </SectionHeading>
        </FadeIn>

        <div className="grid grid-cols-1 gap-px bg-ink/15 md:grid-cols-2 lg:grid-cols-3">
          {qualities.map((q, i) => (
            <FadeIn key={q.title} delay={(i % 3) * 0.08}>
              <div className="h-full bg-bone p-8 md:p-10">
                <div className="mb-6 flex items-center gap-3">
                  <span className="font-serif text-2xl text-terracotta">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="h-px flex-1 bg-ink/20" />
                </div>
                <h3 className="font-serif text-[26px] leading-tight">{q.title}</h3>
                <p className="mt-5 text-sm leading-relaxed text-ink/70">
                  {q.description}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </Container>
    </section>
  );
}
